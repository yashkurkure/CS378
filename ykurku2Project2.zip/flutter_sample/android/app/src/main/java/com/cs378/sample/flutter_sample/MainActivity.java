package com.cs378.sample.flutter_sample;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
